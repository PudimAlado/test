shell.run("wlanplay", "44")
