shell.run("wlanplay", "49")
