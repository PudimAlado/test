shell.run("wlanplay", "7")
