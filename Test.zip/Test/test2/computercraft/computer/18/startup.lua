shell.run("wlanplay", "24")
