shell.run("wlanplay", "5")
