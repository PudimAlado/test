shell.run("wlanplay", "10")
