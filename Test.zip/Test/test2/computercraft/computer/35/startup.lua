shell.run("wlanplay", "48")
