shell.run("wlanplay", "28")
