shell.run("wlanplay", "6")
