shell.run("wlanplay", "41")
