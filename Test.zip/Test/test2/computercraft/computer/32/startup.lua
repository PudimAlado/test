shell.run("wlanplay", "45")
