shell.run("wlanplay", "27")
