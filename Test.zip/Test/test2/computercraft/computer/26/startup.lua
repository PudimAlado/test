shell.run("wlanplay", "32")
