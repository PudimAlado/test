shell.run("wlanplay", "2")
