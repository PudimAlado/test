shell.run("wlanplay", "33")
