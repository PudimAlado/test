modem = peripheral.wrap("top")
local timepassed = 0.0
sleep(60.330360412597656)
modem.transmit(42, 0, "0.8083099722862244")
sleep(2.4070167541503906)
modem.transmit(47, 0, "0.377359002828598")
sleep(1.5482368469238281)
modem.transmit(42, 0, "0.3921569883823395")