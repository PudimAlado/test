shell.run("wlanctrl", "35")
