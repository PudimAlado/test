shell.run("wlanplay", "51")
