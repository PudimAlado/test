shell.run("wlanplay", "8")
