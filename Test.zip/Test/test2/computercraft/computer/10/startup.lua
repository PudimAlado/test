shell.run("wlanplay", "9")
