shell.run("wlanplay", "22")
