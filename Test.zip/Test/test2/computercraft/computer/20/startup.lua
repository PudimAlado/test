shell.run("wlanplay", "26")
