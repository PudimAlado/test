shell.run("wlanplay", "30")
