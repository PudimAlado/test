shell.run("wlanplay", "3")
