shell.run("wlanplay", "43")
