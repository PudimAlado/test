shell.run("wlanplay", "50")
