shell.run("wlanplay", "31")
