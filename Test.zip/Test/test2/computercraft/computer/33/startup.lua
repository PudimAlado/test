shell.run("wlanplay", "46")
