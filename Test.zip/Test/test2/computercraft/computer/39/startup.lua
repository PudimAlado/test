shell.run("wlanplay", "52")
