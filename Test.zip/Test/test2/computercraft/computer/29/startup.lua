shell.run("wlanplay", "42")
