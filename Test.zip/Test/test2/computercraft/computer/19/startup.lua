shell.run("wlanplay", "25")
