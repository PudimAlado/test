shell.run("wlanplay", "47")
