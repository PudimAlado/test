shell.run("wlanplay", "21")
