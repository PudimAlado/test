shell.run("wlanplay", "1")
