shell.run("wlanplay", "12")
